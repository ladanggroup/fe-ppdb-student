import { useState, useEffect } from 'react';
import {
    Dialog,
    DialogTrigger,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import apiClient from '@/api/apiClient';

export default function SelectModal({ label, name, apiUrl, onSelect }) {
    const [options, setOptions] = useState([]); // Menyimpan opsi dari API
    const [selected, setSelected] = useState(null); // Menyimpan nama opsi terpilih
    const [selectedId, setSelectedId] = useState(null); // Menyimpan ID opsi
    const [search, setSearch] = useState(''); // Input pencarian
    const [isOpen, setIsOpen] = useState(false); // Status modal

    useEffect(() => {
        setSelected(null);
        setSelectedId(null);
    }, [apiUrl]);

    /**
     * Fetch data from API.
     *
     * @returns {Promise<void>}
     */
    const fetchData = async () => {
        try {
            const response = await apiClient.get(apiUrl);
            setOptions(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    // Filter opsi berdasarkan pencarian
    const filteredOptions = options.filter((option) =>
        option.name.toLowerCase().includes(search.toLowerCase()),
    );

    // Saat user memilih opsi
    const selectOption = (option) => {
        setSelected(option.name);
        setSelectedId(option.id);
        setIsOpen(false);
        onSelect(option.id);
    };

    // just fetch when open is true
    useEffect(() => {
        if (isOpen === true) {
            fetchData();
        }
    }, [isOpen]);

    return (
        <div className="relative">
            {/* Button untuk membuka modal */}
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                    <Input
                        value={selected || label || 'Pilih opsi...'}
                        readOnly
                        className="text-left"
                    />
                </DialogTrigger>

                <DialogContent className="sm:max-w-[425px] bg-white dark:bg-slate-800">
                    {/* Header Modal */}
                    <DialogHeader>
                        <DialogTitle>{label ?? 'Pilih Opsi'}</DialogTitle>
                        <DialogDescription>
                            Gunakan input pencarian untuk menemukan opsi yang
                            tersedia.
                        </DialogDescription>
                    </DialogHeader>

                    {/* Input Pencarian */}
                    <Input
                        type="text"
                        placeholder="Cari..."
                        className="mb-2"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />

                    {/* List Pilihan */}
                    <div className="max-h-80 overflow-y-auto rounded p-2 text-gray-700 dark:text-gray-200">
                        {filteredOptions.length > 0 ? (
                            filteredOptions.map((option) => (
                                <div
                                    key={option.id}
                                    className="cursor-pointer p-2 hover:bg-yellow-100 dark:hover:text-slate-800"
                                    onClick={() => selectOption(option)}
                                >
                                    {option.name}
                                </div>
                            ))
                        ) : (
                            <p className="text-gray-500">Tidak ada hasil.</p>
                        )}
                    </div>

                    {/* Tombol Tutup */}
                    <Button
                        variant="destructive"
                        onClick={() => setIsOpen(false)}
                        className="mt-2"
                    >
                        Tutup
                    </Button>
                </DialogContent>
            </Dialog>
        </div>
    );
}

// import { useState, useEffect } from 'react';
// import {
//   Dialog,
//   DialogTrigger,
//   DialogContent,
//   DialogHeader,
//   DialogTitle,
//   DialogDescription,
//   DialogFooter
// } from '@/components/ui/dialog';
// import { Input } from '@/components/ui/input';
// import { Button } from '@/components/ui/button';
// import { X } from 'lucide-react';
// import apiClient from '@/api/apiClient';

// export default function SelectModal({ label, name, apiUrl, onSelect }) {
//   const [options, setOptions] = useState([]);
//   const [selected, setSelected] = useState(null);
//   const [selectedId, setSelectedId] = useState(null);
//   const [search, setSearch] = useState('');
//   const [isOpen, setIsOpen] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);

//   useEffect(() => {
//     setSelected(null);
//     setSelectedId(null);
//   }, [apiUrl]);

//   const fetchData = async () => {
//     setIsLoading(true);
//     try {
//       const response = await apiClient.get(apiUrl);
//       setOptions(response.data);
//     } catch (error) {
//       console.error('Error fetching data:', error);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const filteredOptions = options.filter((option) =>
//     option.name.toLowerCase().includes(search.toLowerCase())
//   );

//   const selectOption = (option) => {
//     setSelected(option.name);
//     setSelectedId(option.id);
//     setIsOpen(false);
//     onSelect(option.id);
//   };

//   useEffect(() => {
//     if (isOpen) {
//       fetchData();
//     }
//   }, [isOpen]);

//   return (
//     <div className="relative">
//       <Dialog open={isOpen} onOpenChange={setIsOpen}>
//         <DialogTrigger asChild>
//           <Button variant="outline" className="w-full justify-start">
//             {selected || label || 'Pilih opsi...'}
//           </Button>
//         </DialogTrigger>

//         <DialogContent className="sm:max-w-[425px] bg-white dark:bg-slate-800">
//           <DialogHeader>
//             <DialogTitle>{label || 'Pilih Opsi'}</DialogTitle>
//             <DialogDescription>
//               Cari dan pilih {label?.toLowerCase() || 'opsi'} dari daftar
//             </DialogDescription>
//           </DialogHeader>

//           <div className="grid gap-4 py-4">
//             <Input
//               type="text"
//               placeholder="Cari..."
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               className="w-full"
//             />

//             <div className="max-h-[300px] overflow-y-auto rounded-md border">
//               {isLoading ? (
//                 <div className="flex items-center justify-center p-4">
//                   <p>Memuat data...</p>
//                 </div>
//               ) : filteredOptions.length > 0 ? (
//                 <ul className="divide-y">
//                   {filteredOptions.map((option) => (
//                     <li
//                       key={option.id}
//                       className="cursor-pointer p-3 hover:bg-accent hover:text-accent-foreground transition-colors"
//                       onClick={() => selectOption(option)}
//                     >
//                       {option.name}
//                     </li>
//                   ))}
//                 </ul>
//               ) : (
//                 <div className="p-4 text-center text-muted-foreground">
//                   {search ? 'Tidak ditemukan hasil' : 'Tidak ada data tersedia'}
//                 </div>
//               )}
//             </div>
//           </div>

//           <DialogFooter>
//             <Button 
//               type="button" 
//               variant="outline"
//               onClick={() => setIsOpen(false)}
//             >
//               Tutup
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
//     </div>
//   );
// }